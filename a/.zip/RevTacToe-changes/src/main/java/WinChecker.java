//making this an interface for testing later on

public interface WinChecker {
    void checkWinX(int XCoord);
    void checkWinY(int YCoord);
}
